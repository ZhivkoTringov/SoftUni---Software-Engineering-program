function solve(input){
 for (const key in input) {
    console.log(key);
    let {body, id, title} = input[key];
    console.log(title);
 }

 Object.entries(input).forEach(([key, value]) =>
 console.log(key, value.title))
 
 
}







solve({
    "-MSbypx-13fHPDyzNRtf": {
        "body": "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perferendis maiores eligendi quos quidem ex numquam hic. Eos quos similique voluptates accusamus quae voluptas magni ad a ipsum, quia enim debitis cumque quibusdam exercitationem architecto sint nostrum dolorum dolor repudiandae nulla deserunt, dolorem itaque!",
        "id": "-MSbypx-13fHPDyzNRtf",
        "title": "Unit Testing And Modules"
    },
    "-MSbz99qxklK-5rZWGmt": {
        "body": "Quisquam beatae rerum repudiandae distinctio nesciunt nemo dolorem facilis aspernatur, totam, laudantium sunt amet non, itaque voluptate quae cumque tempore autem similique. Quisquam nemo cupiditate, facere obcaecati iure eveniet illo recusandae! Pariatur magnam commodi, doloremque, beatae unde facilis soluta blanditiis ex debitis quisquam, nostrum voluptates.",
        "id": "-MSbz99qxklK-5rZWGmt",
        "title": "REST Services And AJAX"
    },
    "-MSbzSdzWBvBHJN7gdRw": {
        "body": "Nesciunt facere, omnis exercitationem neque quisquam optio quidem distinctio laboriosam libero consequuntur aperiam, id possimus accusamus ad eaque quis quas molestiae. Esse praesentium cumque quae nobis atque eligendi commodi nam dolores, aperiam vero quia quaerat, soluta, maiores molestiae voluptatum. Modi doloribus consequatur explicabo enim, voluptate nostrum amet expedita natus tempore exercitationem nesciunt quasi quidem eaque.",
        "id": "-MSbzSdzWBvBHJN7gdRw",
        "title": "Asynchronous Programming"
    },
    "-MSbziiMKjPeV03elBfK": {
        "body": "Aspernatur sapiente atque autem, corrupti accusamus animi dolorem asperiores nobis voluptate iure incidunt impedit ex quasi aliquid inventore molestiae totam vitae ullam beatae pariatur dolor eius provident! Deserunt, explicabo aliquid quasi distinctio quisquam vitae, odit perspiciatis alias, quibusdam sunt obcaecati eveniet. Doloribus minima ad culpa harum aliquid incidunt minus laboriosam perspiciatis natus accusamus corrupti, recusandae maxime ex possimus.",
        "id": "-MSbziiMKjPeV03elBfK",
        "title": "Remote Databases"
    },
    "-MSbzvqGMJAXR1syO-nz": {
        "body": "Minima minus iure reiciendis sequi error, impedit facere veritatis architecto accusamus nulla atque temporibus quas quaerat sed harum laudantium culpa placeat consequatur cupiditate officia soluta dolores.Praesentium natus molestiae illo a quisquam omnis corporis harum ipsum iure quam nobis tenetur necessitatibus reprehenderit quas et, ipsa nostrum, dolorem quasi mollitia quo? Doloremque eaque corporis obcaecati reiciendis quidem perferendis repudiandae tempora cupiditate magnam nulla assumenda placeat est vel vitae nesciunt asperiores consectetur, modi dignissimos rem maxime fuga eius.",
        "id": "-MSbzvqGMJAXR1syO-nz",
        "title": "Templating"
    },
    "-MSc-8DwUmBi8NG52eOH": {
        "body": "Reiciendis veniam totam natus reprehenderit dolore adipisci consectetur placeat numquam nemo eum minus necessitatibus rem, possimus vitae iusto, fugiat molestiae quos, maiores tenetur cumque illo dicta enim quod exercitationem. Esse, ipsum modi eligendi itaque debitis suscipit asperiores. Delectus maxime tempore, inventore, dolores eum esse nulla quis harum amet tempora, aspernatur blanditiis obcaecati voluptates neque repudiandae sequi dignissimos?",
        "id": "-MSc-8DwUmBi8NG52eOH",
        "title": "Routing"
    }
})