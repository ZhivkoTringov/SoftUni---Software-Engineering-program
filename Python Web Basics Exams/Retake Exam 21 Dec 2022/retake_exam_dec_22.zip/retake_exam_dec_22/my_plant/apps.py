from django.apps import AppConfig


class MyplantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'retake_exam_dec_22.my_plant'
